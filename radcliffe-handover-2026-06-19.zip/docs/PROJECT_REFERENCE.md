# Redcliffe Project Reference

## Current Shape

This project began as a static Redcliffe Advisory website:

- Public pages are plain HTML files in the repository root.
- Shared styling lives in `styles.css`.
- Shared public behaviour lives in `site.js`.
- Production previously used `nginxinc/nginx-unprivileged` to serve the static files on port `3007`.
- Kubernetes resources deploy into the `radcliffe` namespace.

## Key Public Pages

- `Homepage.html` - main landing page.
- `Practice.html` - Chair and CEO counsel page.
- `Whos-Who.html` - Karina Robinson profile page.
- `The-City.html` - City of London and quantum future page.
- `Summit.html` - City Quantum and AI Summit page.
- `Agenda.html` - Summit agenda page.
- `Articles.html` - articles and long reads page.
- `Ethics.html` - ethics and independence page.

`The City Quantum & AI Summit.html` appears to be an archived/generated standalone export. It is not part of the main navigation and should be treated carefully before editing.

## CMS Architecture

The upgraded application uses a small Node/Express server instead of nginx. It still serves the same static HTML, CSS, JavaScript, and image assets, but also provides:

- Public CMS API:
  - `GET /api/content`
  - `GET /api/media/:key`
  - `POST /api/contact`
- Admin portal:
  - `GET /admin`
  - `POST /admin/login`
  - `POST /admin/logout`
  - `GET /api/admin/content`
  - `PUT /api/admin/content/:key`
  - `GET /api/admin/media`
  - `POST /api/admin/media/:key`
  - `DELETE /api/admin/media/:key`
  - `GET /api/admin/sections`
  - `PUT /api/admin/sections/:key`
  - `DELETE /api/admin/sections/:key`
  - `GET /api/admin/messages`

Content is stored in PostgreSQL:

- `cms_content` stores editable text/HTML values.
- `cms_media` stores uploaded image bytes, MIME type, filename, alt text, and labels.
- `cms_sections` stores page section controls:
  - Existing static sections are seeded with stable keys and can be enabled/disabled.
  - CMS-authored sections can be added, edited, reordered, enabled/disabled, and deleted.
  - Dynamic sections support text, text plus image, and dark band layouts.
- `contact_messages` stores public contact form submissions.

The frontend enhancement script `cms-client.js` fetches CMS values after page load and applies them to elements marked with:

- `data-cms-key="some.key"` for text or HTML.
- `data-cms-mode="html"` when the value should be applied with `innerHTML`.
- `data-cms-image="some.image.key"` for image overrides from the database.
- `data-cms-section="page.section"` for existing sections that can be hidden from the CMS.
- `data-cms-sections` for the insertion point where CMS-authored sections are rendered.

If the CMS API or database is unavailable, the static hard-coded HTML remains visible.

## Admin Portal

The public top navigation includes an `Admin` link to `/admin`.

The admin portal is page-first and has four editor-facing areas:

- `Pages` - choose a public page, then manage that page's visible sections and editable text in one place.
- `Media Library` - replace images, upload images for new sections, or restore the original static website image.
- `Messages` - view recent contact form submissions.
- `Settings` - edit global announcement and contact routing content.

Normal editors do not need to work with keys, page slugs, image keys, or sort values. Those implementation details remain available only in collapsed advanced panels. Hiding a built-in section sets `enabled=false`; deleting an admin-added section removes it from the database.

## Admin Credentials

Default admin credentials are configured to match the request:

- Username: `admin`
- Password: `radcliffe`

They can be overridden with:

- `ADMIN_USERNAME`
- `ADMIN_PASSWORD`
- `SESSION_SECRET`

For a public production deployment, replace these defaults through Kubernetes secrets or environment variables.

## Local Runtime

The app listens on port `3007`.

Docker Compose includes:

- `qcx-web` - Node/Express application image.
- `radcliffe-db` - PostgreSQL database image.

Important environment variables:

- `PORT=3007`
- `DATABASE_URL=postgres://radcliffe:radcliffe@radcliffe-db:5432/radcliffe`
- `POSTGRES_DB=radcliffe`
- `POSTGRES_USER=radcliffe`
- `POSTGRES_PASSWORD=radcliffe`

## Kubernetes Runtime

`deployment.yaml` now contains:

- Web `Deployment`
- Web `Service`
- PostgreSQL `StatefulSet`
- PostgreSQL `Service`
- PostgreSQL `PersistentVolumeClaim` template
- App `Secret`
- Ingress
- HPA

All resources use namespace `radcliffe`.

## Future Editing Notes

To make a new static element editable:

1. Add a stable key to the HTML element, for example:
   `<h1 data-cms-key="practice.hero.title" data-cms-mode="html">Chair &amp; CEO Counsel</h1>`
2. Add a seed row for the key in `server.js` so it appears in the admin portal by default.
3. For images, add `data-cms-image="some.image.key"` to the `img` element and add a media seed in `server.js`.
4. For whole static sections, add `data-cms-section="page.section"` to the section and add a section seed in `server.js`.

Keep CMS keys stable. Changing keys disconnects existing database content from the page.

## Contact Form

All former `mailto:` enquiry links now route to `Contact.html`.

The contact page uses CMS keys for editable details:

- `contact.recipient.email` - backend recipient email used for stored submissions and optional SMTP delivery.
- `contact.details.email` - public email text shown on the contact page.
- `contact.details.location` - public location text.
- `contact.details.response` - public response note.
- `contact.hero.title` and `contact.hero.lede` - page hero copy.

Submissions are always stored in `contact_messages`. SMTP delivery is optional and enabled only when these environment variables are configured:

- `SMTP_HOST`
- `SMTP_PORT`
- `SMTP_SECURE`
- `SMTP_USER`
- `SMTP_PASSWORD`
- `CONTACT_FROM_EMAIL`
