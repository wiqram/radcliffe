// Redcliffe Advisory — shared site script (v2, blue & white)
(function () {
  // 1) Header — condense on scroll + retract announcement bar
  const header = document.getElementById('header');
  function onScroll() {
    const scrolled = window.scrollY > 24;
    if (header) header.classList.toggle('scrolled', scrolled);
    document.body.classList.toggle('is-scrolled', scrolled);
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  // 2) Mobile nav toggle
  const btn = document.getElementById('navToggle');
  const nav = document.getElementById('nav');
  if (btn && nav) {
    btn.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    nav.querySelectorAll('a').forEach((a) =>
      a.addEventListener('click', () => {
        nav.classList.remove('open');
        btn.setAttribute('aria-expanded', 'false');
      })
    );
  }

  // 3) Reveal on scroll (JS-gated — content is visible by default in CSS)
  document.documentElement.classList.add('js-reveal');

  // 3a) Auto-stagger: let the children of common grids/lists cascade in
  //     sequence rather than popping as one block.
  const STAGGER_SEL = [
    '.entries', '.enter-grid', '.journal-list', '.practice-list', '.partner-grid',
    '.partner-roles', '.cv-list', '.other-list', '.agenda-block',
    '.audience-list', '.meta-row', '.hero-facts'
  ].join(', ');
  document.querySelectorAll(STAGGER_SEL).forEach((group) => {
    const kids = Array.from(group.children);
    if (kids.length < 2) return;
    group.classList.add('reveal', 'reveal-stagger');
    kids.forEach((c, i) => {
      // The parent now drives the cascade — drop any per-child reveal so the
      // two hidden-states don't fight each other.
      c.classList.remove('reveal');
      c.style.setProperty('--si', Math.min(i, 8));
    });
  });

  const io = new IntersectionObserver(
    (entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          e.target.classList.add('in');
          io.unobserve(e.target);
        }
      });
    },
    { threshold: 0.12, rootMargin: '0px 0px -8% 0px' }
  );
  document.querySelectorAll('.reveal').forEach((el) => io.observe(el));
  // Safety: if anything stalls, reveal everything after 2.5s
  setTimeout(() => {
    document.querySelectorAll('.reveal:not(.in)').forEach((el) => el.classList.add('in'));
  }, 2500);

  // 4) Active-page nav highlight is applied server-side by the theme.

  // 5) Testimonial rotator (Articles page) — only if present
  const tq = document.getElementById('t-quote');
  if (tq) {
    const data = window.__TESTIMONIALS || [];
    const aEl = document.getElementById('t-attrib');
    const cEl = document.getElementById('t-count');
    let i = 0;
    function render() {
      const t = data[i];
      tq.style.opacity = 0;
      aEl.style.opacity = 0;
      setTimeout(() => {
        tq.innerHTML = '<span class="open-q">“</span>' + t.q + '<span class="close-q">”</span>';
        aEl.innerHTML = '<span class="name">' + t.name + '</span> · ' + t.org;
        if (cEl) cEl.textContent = String(i + 1).padStart(2, '0') + ' / ' + String(data.length).padStart(2, '0');
        tq.style.opacity = 1;
        aEl.style.opacity = 1;
      }, 220);
    }
    tq.style.transition = 'opacity 320ms ease';
    aEl.style.transition = 'opacity 320ms ease';
    const prev = document.getElementById('t-prev');
    const next = document.getElementById('t-next');
    if (prev) prev.addEventListener('click', () => { i = (i - 1 + data.length) % data.length; render(); });
    if (next) next.addEventListener('click', () => { i = (i + 1) % data.length; render(); });
    if (data.length) render();
  }

  // 6) LinkedIn posts (SociableKit) — the widget loads once it is close to
  // being seen, so visitors who never scroll that far do not download it. The
  // feed lists every recent post, so the page shows the first rows and a
  // button opens the rest (the button only appears when there is more).
  const linkedin = document.querySelector('.linkedin-feed[data-linkedin-src]');
  if (linkedin) {
    const toggle = document.querySelector('.linkedin-toggle');
    const loadLinkedIn = () => {
      if (linkedin.dataset.loaded) return;
      linkedin.dataset.loaded = '1';
      const script = document.createElement('script');
      script.src = linkedin.dataset.linkedinSrc;
      script.async = true;
      linkedin.appendChild(script);
    };
    if (toggle) {
      const sync = () => {
        toggle.hidden = !(linkedin.classList.contains('is-collapsed') && linkedin.scrollHeight > linkedin.clientHeight + 24);
      };
      toggle.addEventListener('click', () => {
        linkedin.classList.remove('is-collapsed');
        toggle.setAttribute('aria-expanded', 'true');
        toggle.hidden = true;
      });
      if ('ResizeObserver' in window) new ResizeObserver(sync).observe(linkedin.firstElementChild);
      else toggle.hidden = false;
      window.addEventListener('resize', sync);
    }
    if ('IntersectionObserver' in window) {
      const watcher = new IntersectionObserver((entries) => {
        if (entries.some((entry) => entry.isIntersecting)) { watcher.disconnect(); loadLinkedIn(); }
      }, { rootMargin: '400px 0px' });
      watcher.observe(linkedin);
    } else {
      loadLinkedIn();
    }
  }
})();
