# Putting the website live on WordPress

**This is the guide for the deployment team. Follow it top to bottom.**

You do not need to be a developer, write any code, or install anything on your
computer. Everything happens inside WordPress in a web browser, and it takes
about twenty minutes.

---

## What you have been given

| File or folder | What it is |
| --- | --- |
| `1-theme-to-upload/redcliffe-advisory.zip` | **The file you upload to WordPress.** Do not unzip it |
| `2-theme-files/redcliffe-advisory/` | The same thing already unzipped, in case your host wants files uploaded by FTP instead |
| `START-HERE.md` | This guide: putting the website live |
| `WEBSITE-GUIDE.md` | The guide for afterwards: changing words and pictures, adding sections, backups. It is also built into the website's dashboard under **Website guide** |

## What you need before you start

1. **The login for the WordPress site.** On Hostinger, log in at
   https://hpanel.hostinger.com, click **Websites**, and press **WP Admin**
   next to the site — no separate WordPress password is needed. Your WordPress
   account must be an **Administrator**, which the Hostinger one is.
2. **About twenty minutes.**

> Not on Hostinger? Any WordPress host works. On WordPress.com the site must be
> on the **Business plan or higher** to upload a theme.

You do **not** need a database, a server, or any settings from the old website.
Everything the site needs is inside the theme file.

---

## What will happen when you do this

Worth knowing, so nothing comes as a surprise.

The moment you activate the theme in Step 3, WordPress builds the entire
website by itself:

- **Nine pages are created** — Home, Chair Advisory, Who's Who, The City of
  London, Summit, Agenda, Articles, Ethics, Contact
- **The homepage is set** as the site's front page
- **The top menu is built** with all the links in the right order
- **The contact form starts working**, and messages appear in WordPress under
  **Enquiries**
- **A "Website guide"** appears in the left-hand menu, explaining how to look
  after the site from then on

You do not have to create any of that by hand. If you have run it before, doing
it again is safe: existing pages are reused, never duplicated.

---

# Step 1 — Log in to WordPress

**On Hostinger:** go to https://hpanel.hostinger.com, log in, click
**Websites** in the left-hand menu, and press the **WP Admin** button next to
the site.

**Anywhere else:** go to your site's admin address and log in:

```
https://your-site-address/wp-admin
```

**You should see:** the WordPress dashboard, with a dark menu down the left-hand
side.

---

# Step 2 — Upload the theme

1. In the left-hand menu, click **Appearance**, then **Themes**.
2. Click the **Add New Theme** button at the top (on some versions it just says
   **Add New**).
3. Click **Upload Theme** at the top of the next screen.
4. Click **Choose File** and select **`redcliffe-advisory.zip`** from the
   `1-theme-to-upload` folder you were given.

   > Select the **zip file itself**. Do not unzip it first, and do not select
   > the folder from `2-theme-files`.

5. Click **Install Now**.
6. Wait a few seconds.

**You should see:** a message saying *Theme installed successfully*, with links
underneath saying **Live Preview** and **Activate**.

> **If WordPress says the theme is already installed** (because you are
> putting a newer version live), click **Replace active with uploaded**. Your
> words, pictures and enquiries are kept.
>
> **If there is no "Upload Theme" button** on WordPress.com, the site is not on
> the Business plan. Upgrade the plan, then come back to this step.

---

# Step 3 — Activate the theme

Click **Activate**.

This is the step that builds the website. It takes a couple of seconds.

**You should see:** a green message at the top of the screen saying *The
Redcliffe Advisory website is set up*, with links to view the site and to edit
its words and pictures.

---

# Step 4 — Look at the website

In the left-hand menu, hover over the site name at the very top and click
**Visit Site**.

Check each of these:

- [ ] The homepage loads, with the portrait photograph and the dark blue announcement
      strip across the top
- [ ] The menu along the top shows: Chair Advisory, Who's Who, The City of
      London, Summit, Articles, Ethics, and an **Enquire** button
- [ ] Clicking each menu item opens a page that looks finished and properly
      styled
- [ ] The Contact page shows a form with Name, Email, Organisation, Topic and
      Message

If pages look plain and unstyled, see [If something looks
wrong](#if-something-looks-wrong) at the end.

---

# Step 5 — Set the email address for enquiries

Contact form messages are emailed to one address. Set it now.

1. In the left-hand menu, click **Appearance**, then **Customize**.
2. Click **Redcliffe Advisory** in the list.
3. Click **Contact page**.
4. Find **Send enquiries to** and enter the correct email address.
5. Click **Publish** at the top.

**Then test it:** open the Contact page on the live website, fill in the form
and send it. You should see *"Thank you. Your message has been received."*

Check two things afterwards:

- The email arrives (**look in the spam folder too**)
- The message appears in WordPress under **Enquiries** in the left-hand menu

> Every message is saved under **Enquiries** whether or not the email goes out,
> so an enquiry can never be lost. If the **Emailed** column says *No*, the
> website is fine — it is the email sending that needs attention. See the last
> section.

---

# Step 6 — Point redcliffeadvisory.com at the site

**Do this last, once Steps 4 and 5 are confirmed working.**

Until you do this, the old website is still the one the public sees. That is
your safety net.

**On Hostinger:** go to https://hpanel.hostinger.com → **Websites** →
**Dashboard** next to the site → the red *Every website needs a domain* note →
**Connect domain**, enter `redcliffeadvisory.com`, click **Next** and follow
the instructions. If the domain is registered elsewhere, Hostinger shows you
the nameserver settings to enter there; its **Agent** help chat (bottom right)
will check the change for you.

**On WordPress.com:** go to **Upgrades → Domains → Add a domain → Use a domain I
own**, enter `redcliffeadvisory.com`, and follow the instructions it gives you.

**Anywhere else:** point the domain's DNS at your host as your hosting company
instructs, and set the correct address under **Settings → General**.

Either way:

- Make **`www.redcliffeadvisory.com`** the primary address, so the version
  without `www` redirects to it. That matches how the site works today.
- The padlock (HTTPS) is set up automatically. There is nothing to buy.
- DNS changes take anywhere from a few minutes to a few hours to take effect.

---

# How to change the website from now on

**The full guide is `WEBSITE-GUIDE.md`, and the same guide is inside
WordPress under Website guide in the left-hand menu.** In short:

## Words and pictures already on the site

**Appearance → Customize.** The website appears on the right with a small
blue **pencil** next to every piece of text and on every photograph. Click a
pencil, type, and click **Publish**. Or click **Redcliffe Advisory** on the
left and pick a page to see everything on it listed in order: every headline,
date, name and paragraph, the photographs, and switches for hiding whole
sections. **Clearing a box puts the original wording back**, so nothing can be
left blank by accident. The announcement strip at the top of every page is
under **Top of every page**.

## The Summit agenda

**Pages → Agenda → Edit.** The programme is there exactly as it appears on
the website. Click a time, a title or a description and type. To add a
session, press **+**, open **Patterns → Redcliffe Advisory** and choose
**Agenda: a time slot**. Click **Update** to save.

## New sections, speakers and pictures

**Pages → Edit** on any page. The page looks mostly empty in the editor — the
designed part is not shown there. Press **+**, open **Patterns**, choose
**Redcliffe Advisory**, and pick a ready-made section (heading and text, a
speaker, a photograph with caption, a gallery, a quotation, and so on).
Whatever you add appears at the bottom of that page on the website, styled to
match. Click **Update** to save.

**Do not delete the nine main pages**, or the menu links will stop working.

## The menu

**Appearance → Menus.** Reorder, rename or remove links here.

To make a link look like the dark blue **Enquire** button, open **Screen Options** at
the top right, tick **CSS Classes**, then type `cta` into the CSS Classes box
for that link.

## Enquiries

**Enquiries** in the left-hand menu. Every contact form message is listed here
with the sender's name, email and topic. Pressing **Reply** on the email
notification writes back to the person who sent it.

---

# If something looks wrong

| What you see | What it means | What to do |
| --- | --- | --- |
| No **Upload Theme** button | The WordPress.com plan is too low | Upgrade to Business, then retry Step 2 |
| *The package could not be installed* | The wrong file was chosen | Choose `redcliffe-advisory.zip` itself, not a folder and not a file from inside it |
| Pages look plain, with no styling | The theme is installed but not activated | Appearance → Themes → **Activate** on Redcliffe Advisory |
| A new section is not showing, or looks unstyled | An old copy is cached | Reload with Ctrl+F5; on Hostinger, hover **LiteSpeed Cache** in the top bar and click **Purge All** |
| The menu at the top is empty | The menu was edited or removed | Appearance → Menus → assign a menu to the **Primary menu** location |
| A menu link leads to the homepage | That page was deleted | Pages → check the page exists; restore it from Trash if not |
| The homepage shows a list of blog posts | The front page setting was changed | Settings → Reading → *Your homepage displays: A static page* → Homepage: **Home** |
| Contact form messages arrive but no email does | The site cannot send email | Check spam first. On Hostinger, ask its help chat (the **Agent** button) to enable email sending from WordPress; elsewhere ask your host or install an SMTP plugin. Messages are still safe under **Enquiries** |
| Photographs you uploaded do not appear | The change was not published | Reopen the Customizer and click **Publish** |
| The Articles page shows a list of blog posts | The *Posts page* setting points at it | Settings → Reading → Posts page: **— Select —** → Save Changes |

**Nothing here can break the design.** If an edit goes wrong, clear the box you
changed and the original wording comes back.
